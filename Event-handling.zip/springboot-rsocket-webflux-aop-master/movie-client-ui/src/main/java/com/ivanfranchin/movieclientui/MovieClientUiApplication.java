package com.ivanfranchin.movieclientui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieClientUiApplication {

    public static void main(String[] args) {
        SpringApplication.run(MovieClientUiApplication.class, args);
    }
}
