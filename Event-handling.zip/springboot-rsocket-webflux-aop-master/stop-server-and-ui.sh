#!/usr/bin/env bash

docker stop movie-server movie-client-ui
