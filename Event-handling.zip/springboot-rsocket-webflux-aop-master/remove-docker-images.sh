#!/usr/bin/env bash

docker rmi ivanfranchin/movie-server:1.0.0
docker rmi ivanfranchin/movie-client-ui:1.0.0
docker rmi ivanfranchin/movie-client-shell:1.0.0
