package com.ivanfranchin.movieclientshell;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieClientShellApplication {

    public static void main(String[] args) {
        SpringApplication.run(MovieClientShellApplication.class, args);
    }
}
