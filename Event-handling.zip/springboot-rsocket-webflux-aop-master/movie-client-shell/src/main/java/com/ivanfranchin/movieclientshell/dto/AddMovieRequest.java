package com.ivanfranchin.movieclientshell.dto;

public record AddMovieRequest(String imdb, String title) {
}
