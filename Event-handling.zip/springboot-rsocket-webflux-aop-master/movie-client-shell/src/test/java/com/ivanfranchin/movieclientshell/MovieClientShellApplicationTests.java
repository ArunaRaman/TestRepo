package com.ivanfranchin.movieclientshell;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@Disabled
@SpringBootTest
class MovieClientShellApplicationTests {

    @Test
    void contextLoads() {
    }
}
